
var phina = require('./../../build/phina.js');

phina.globalize();


/*
var v = Vector2(1, 2);

console.log(v);
console.log(Vector2);
*/

console.log(Support);

phina.main(function() {
  console.log('run main');
});